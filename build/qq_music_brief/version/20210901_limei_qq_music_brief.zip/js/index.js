/*
 * @Author: Gianni
 * @Date: 2021-08-31 16:00:56
 * @LastEditTime: 2021-09-01 19:27:00
 * @LastEditors: Gianni
 * @Description: *
 * @FilePath: \H5-Project\src\qq_music_brief\js\index.js
 */
$(function () {
  /**
   * 工具函数 - 显示元素
   * @param {*} section 需要显示的的元素类
   * 用法: showSection('.test') showSection('#test')
   *
   */
  let $prevSection
  function showSection(section) {
    if ($prevSection) {
      $prevSection.removeClass('show')
    }
    $prevSection = $(section)
    $prevSection.addClass('show')
  }
  // 默认显示页面
  showSection('.page_noe')

  /**
   * toast信息工具函数
   */
  function showToast(str) {
    let $toast = $(
      '<div class="toast_item"><span class="ani">' + str + '</span></div>'
    )
    $('.wrap').append($toast)
    setTimeout(function () {
      $toast.animate({ opacity: 0 }, 300, null, function () {
        $toast.remove()
      })
    }, 1500)
  }
  // 第一页动画结束
  $('.page_item__title1')[0].addEventListener(
    'animationend',
    function () {
      setTimeout(function () {
        showSection('.page_two')
      }, 1000)
    },
    false
  )
  // 第二页动画结束
  $('.page_item__title2')[0].addEventListener(
    'animationend',
    function () {
      setTimeout(function () {
        showSection('.page_three')
      }, 1000)
    },
    false
  )

  // 第三页动画结束
  $('.page_item__title3')[0].addEventListener(
    'animationend',
    function () {
      setTimeout(function () {
        $('.page_item__mobile1').hide();
        $('.page_three').addClass('page_protocol')
      }, 1000)
    },
    false
  )

  let state = false
  // 勾选用户须知
  $('.wrap').on('change', '#pageProtocolSelect', function () {
    if ($('#pageProtocolSelect').get(0).checked) {
      state = true
      $('.page_protocol__circle').addClass('active')
    } else {
      state = false
      $('.page_protocol__circle').removeClass('active')
    }
  })
  // 点击立即领取按钮 - 判断是否勾选协议
  $('.wrap').on('click', '.page_protocol__btn', function () {
    if(!state) {
      showToast('请先阅读并同意协议')
    } else {
      // 已勾选协议
    }
  })
})
