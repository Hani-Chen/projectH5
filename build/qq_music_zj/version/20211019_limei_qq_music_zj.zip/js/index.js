/*
 * @Author: Gianni
 * @Date: 2021-10-17 10:21:45
 * @LastEditTime: 2021-10-19 22:07:24
 * @LastEditors: Gianni
 * @Description: *
 * @FilePath: \H5-Project\src\qq_music_zj\js\index.js
 */
$(function () {
  // 用户输入的昵称
  let userName = ''
  // 是否存在近期数据
  let userData = true
  testList = [
    '感谢你曾经来过',
    '当想你成为习惯当想你成为习惯当想你成为习惯当想你成为习惯 (DJ R7)',
  ]

  function getRandomNumberByRange(start, end) {
    return Math.floor(Math.random() * (end - start) + start)
  }
  // 用户最近最喜欢的歌曲名称
  let userSongName = testList[getRandomNumberByRange(0, 2)]
  let pageSongId = 1319248

  /**
   * toast信息工具函数
   */
  function showToast(str) {
    var $toast = $(
      '<div class="toast_item"><span class="ani">' + str + '</span></div>'
    )
    $('.wrap').append($toast)
    setTimeout(function () {
      $toast.animate({ opacity: 0 }, 300, null, function () {
        $toast.remove()
      })
    }, 1500)
  }

  let isPlay = false
  /* 判断播放组件是否存在 */
  let playerExist = false
  /* 初始化播放器类 */
  let player
  /* 初始化js时如果有音乐直接暂停 */
  playerExist && player.pause()
  function PlayKernelSong(options) {
    // QQ音乐歌曲id
    this.songId = '' || options.songId
    this.init()
  }
  /* 播放器初始化 */
  PlayKernelSong.prototype.init = function () {
    /* 判断是否存在音乐播放器 */
    playerExist == false && (player = new QMplayer())
    /* 监听音视频播放 */
    player.on('play', function () {
      isPlay = true
      songPlay()
    })
    /* 监听音视频暂停 */
    player.on('pause', function () {
      isPlay = false
      $('.btn_play').removeClass('play')
      $('.play_cd').removeClass('play')
      $('.page_music').removeClass('active')
    })
    /* 监听音视频播放结束后暂停播放 */
    player.on('ended', function () {
      isPlay = false
      $('.btn_play').removeClass('play')
      $('.page_music').removeClass('active')
    })
  }
  /* 歌曲播放 */
  PlayKernelSong.prototype.play = function () {
    playerExist = true
    player.play(this.songId)
  }
  /* 歌曲暂停 */
  PlayKernelSong.prototype.stop = function () {
    playerExist = false
    player.pause()
  }

  function choiceScroll(index) {
    console.log(index);
    let outer = null
    let inner = null
    if (index == 1) {
      outer = $('.data_songname')
      inner = $('.data_songname__inner')
    } else if (index == 6) {
      outer = $('.serp_songname')
      inner = $('.serp_songname__inner')
    }
    let outerWidth = outer.width()
    let innerWidth = inner.width()

    if (innerWidth > outerWidth) {
      let text = inner.text()
      inner.text(text + text)

      let left = 0
      clearInterval(timer)
      var timer = setInterval(function () {
        inner.css({
          transform: 'translate3d(' + left + 'px,0,0)',
        })
        left = left - 1
        if (Math.abs(left) >= inner.width() / 2) {
          left = 0
        }
      }, 30)
    }
  }
  function songPlay() {
    $('.btn_play').addClass('play')
    $('.play_cd').addClass('play')
    $('.page_music').addClass('active')
  }
  audioDemo = new PlayKernelSong({
    songId: pageSongId,
  })
  audioDemo.play()

  // 滑屏组件初始化
  var homeSlide = new iSlider({
    wrap: '.wrap',
    item: '.item',
    lastLocate: false,
    // preventMove: false,
    // isVertical: false,
    onslide: function (index) {
      console.log('当前滑屏页面index: ', index)
      $('.user_name').text(userName)
      // 解锁滚动限制
      homeSlide.lockPrev = true
      homeSlide.lockNext = false
      if (index == 0 || index >= 3) {
        homeSlide.lockNext = true
      }
      if (index == 1 || index == 6) {
        choiceScroll(index)
      }
      if (isPlay) {
        songPlay()
      }
    },
  })

  // 点击返回按钮
  $('.wrap').on('click', '.page_return', function () {
    homeSlide.prev()
  })
  // 点击音乐icon
  $('.wrap').on('click', '.page_music', function () {
    if ($(this).hasClass('active')) {
      audioDemo.stop()
    } else {
      audioDemo.play()
    }
  })
  // 点击首页 - 追忆你的岁月
  $('.wrap').on('click', '.home_btn', function () {
    if ($('.home_input__item').val()) {
      // 暂停音乐
      audioDemo.stop()
      // 获取用户输入昵称
      userName = $('.home_input__item').val()
      $('.user_name').text(userName)
      // 切换下一页
      homeSlide.next()
      // 判断用户是否存在大数据
      !userData && $('.page_data').addClass('page_data__lose')
      $('.data_songname__inner').text(`《${userSongName}》`)
    } else {
      showToast('请输入昵称')
    }
  })

  $('.wrap').on('click', '.btn_play', function () {
    if (!$(this).hasClass('play')) {
      audioDemo = new PlayKernelSong({
        songId: pageSongId,
      })
      audioDemo.play()
    } else {
      // 暂停音乐
      audioDemo.stop()
    }
  })

  $('.wrap').on('click', '.btn_like', function () {
    console.log(pageSongId)
    if (!$(this).hasClass('like')) {
      // 获取songId
      $(this).addClass('like')
    } else {
      $(this).removeClass('like')
    }
  })
  // 点击我要制作
  $('.wrap').on('click', '.execution_btn', function () {
    showScene()
    homeSlide.next()
  })

  let bannerList = {
    aiqing: [
      {
        id: 0,
        url: '../img/scene_item1.png',
      },
      {
        id: 1,
        url: '../img/scene_item2.png',
      },
    ],
    youqing: [
      {
        id: 0,
        url: '../img/scene_item3.png',
      },
      {
        id: 1,
        url: '../img/scene_item4.png',
      },
    ],
    qinqing: [
      {
        id: 0,
        url: '../img/scene_item5.png',
      },
      {
        id: 1,
        url: '../img/scene_item6.png',
      },
    ],
  }
  let myslider
  let sceneIndex = 0
  function showScene() {
    // 滑屏组件初始化
    myslider = new iSlider({
      wrap: '.scene_swiper',
      item: '.scene_swiper__item',
      lastLocate: false,
      // preventMove: false,
      isVertical: false,
      onslide: function (index) {
        console.log('当前滑屏页面index: ', index)
        $(`.pagination_item`).removeClass('active')
        $(`.pagination_item${index}`).addClass('active')
        sceneIndex = index
      },
    })
  }

  let tabIndex = 0
  $('.wrap').on('click', '.scene_tab__item', function () {
    myslider.slideTo(0)
    $('.scene_tab__item').removeClass('active')
    $(this).addClass('active')
    $('.scene_swiper__wrap')
      .removeClass()
      .addClass(`scene_swiper__wrap${$(this).index() + 1} scene_swiper__wrap`)
    tabIndex = $(this).index()
  })

  $('.wrap').on('click', '.scene_btn', function () {
    homeSlide.next()
    showLyrics()
  })

  let lyricList = [
    // 爱情
    {
      lyric: [
        {
          text: '水云间醇香飘逸\n带我找到通往你心里的路',
        },
        {
          text: '世间多少平凡的憧憬\n但愿携手铺开风景',
        },
      ],
    },
    // 友情
    {
      lyric: [
        {
          text: '手捧无尽的梦想 珍诚无畏\n陪你追梦 一起并肩远方',
        },
        {
          text: '畅饮时代珍品\n让我们重温岁月的传奇',
        },
      ],
    },
    // 亲情
    {
      lyric: [
        {
          text: '听耳畔传来熟悉声音\n让我频频回望家的方向',
        },
        {
          text: '万家灯火把前路都照亮\n别担心我会一直都安好',
        },
      ],
    },
  ]

  // 显示歌词选择页
  function showLyrics() {
    $('.lyric_content__title')
      .removeClass()
      .addClass(`lyric_content__title lyric_content__title${tabIndex + 1}`)
    $('.lyric_content__1').text(lyricList[tabIndex].lyric[0].text)
    $('.lyric_content__2').text(lyricList[tabIndex].lyric[1].text)
  }

  let lyricIndex = 0
  $('.wrap').on('click', '.lyric_content__item', function () {
    $('.lyric_content__item').removeClass('check')
    $(this).addClass('check')
    lyricIndex = $(this).index()
  })

  $('.wrap').on('click', '.lyric_btn', function () {
    if ($('.lyric_content__item').hasClass('check')) {
      homeSlide.next()
      console.log('值：', tabIndex * 2 + (sceneIndex + 1))
      $('.page_serp')
        .removeClass()
        .addClass(`item page_serp page_serp${tabIndex * 2 + (sceneIndex + 1)}`)
      $('.share__img').attr(
        'src',
        `./img/test_share_img${tabIndex * 2 + (sceneIndex + 1)}.jpg`
      )
      $('.serp_lyric__text').text(lyricList[tabIndex].lyric[lyricIndex].text)
      $('.serp_songname__inner').text(`《${userSongName}》`)
    } else {
      showToast('请选择走心歌词')
    }
  })

  $('.wrap').on('click', '.serp_btn__left', function () {
    homeSlide.slideTo(3)
    lyricIndex = 0
    tabIndex = 0
    sceneIndex = 0
  })
})
