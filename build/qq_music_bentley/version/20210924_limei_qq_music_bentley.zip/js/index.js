/*
 * @Author: Gianni
 * @Date: 2021-09-18 10:06:51
 * @LastEditTime: 2021-09-24 18:27:57
 * @LastEditors: Gianni
 * @Description: *
 * @FilePath: \H5-Project\src\qq_music_bentley\js\index.js
 */
$(function () {
  let selectSceneIndex = 0
  // 创建创建场景选择页轮播
  let selectScene = new Swiper('.select_swiper', {
    // 如果需要分页器
    pagination: '.swiper-pagination',
    // 轮播可循环切换
    loop: true,
    // 轮播分页器可点击切换
    paginationClickable: true,
  })

  // 场景选择页 - 点击确认场景按钮
  $('.select_operation__btn').on('click', function () {
    console.log('selectSceneIndex', selectScene.realIndex)
    selectSceneIndex = selectScene.realIndex
    showBodyPage(selectScene.realIndex)
  })
  // 场景选择页 - 点击上一个场景
  $('.select_operation__prev').click(function () {
    selectScene.slidePrev()
  })
  // 场景选择页 - 点击下一个场景
  $('.select_operation__next').click(function () {
    selectScene.slideNext()
  })

  // 需要播放的原生音频
  let audioUrl = ''
  // 需要播放的songId
  let audioId = ''
  function showBodyPage(index) {
    audioUrl = './audio/test1.mp3'
    // 播放
    let audio1 = new OriginalAudio({ url: audioUrl, loop: true })
    audio1.play()

    $('.page_body').addClass(`body_${Number(index) + 1}`)
    showSection('.page_body')
  }

  $('.body_inner').scroll(function (event) {
    if (
      $('.body_gesture').offset().left + $('.body_gesture').width() / 2 <
      350
    ) {
      $('.body_operation__prev').addClass('show')
      $('.body_operation__next').removeClass('show')
      $('.body_operation__hint').text('点击光圈继续探索').show('slow')
    } else {
      $('.body_operation__next').addClass('show')
      $('.body_operation__prev').removeClass('show')
      $('.body_operation__hint').text('滑动探索').show('slow')
    }
  })

  $('.body_gesture').on('click', function () {
    $('.page_detail').removeClass('cardoor_1', 'cardoor_2', 'cardoor_3', 'cardoor_4')
    $('.page_cardoor').addClass(`cardoor_${Number(selectSceneIndex) + 1}`)
    // 显示车门页
    showSection('.page_cardoor')

    audioUrl = ''
    // 播放
    new OriginalAudio({ url: audioUrl })
  })

  let lockNext = false
  $('.cardoor_gesture').on('click', function () {
    if (lockNext) {
      return
    } else {
      lockNext = true
      audioUrl = './audio/test2.mp3'
      // 播放
      let audio3 = new OriginalAudio({ url: audioUrl, isPlay: true })
      audioUrl = ''
      audio3.play()
      setTimeout(function () {
        showDetailPage()
      }, 500)
    }
  })

  let detailData = [
    {
      songId: 1703265,
      data: [
        {
          title: '独运匠心，智雅相融',
          text: '宾利三面翻转中控面板(Bentley Rotating Display)\n让超卓技艺与前沿科技缔造非凡格调',
        },
        {
          title: '私享天籁，聆听新境',
          text: 'Naim* 倾力打造临场感音乐空间\n演绎听觉的饕餮盛宴',
        },
        {
          title: '华美格调，瞬息倾心',
          text: '5331块菱形切面交织而成的钻石滚花饰面\n于细节处雕琢精致肌理，尽显华美气韵',
        },
      ],
    },
    {
      songId: 125751527,
      data: [
        {
          title: '落座其中，惬意奢享',
          text: '立体放射式菱形格纹融合传统绗缝和刺绣工艺\n手工温情让典雅之美动人呈现',
        },
        {
          title: '灵感飞跃，风华夺目',
          text: '以宾利双翼元素为灵感的座舱设计\n收放自如的灵动线条优雅流淌，尽展华美风姿',
        },
        {
          title: '触启无垠，悦享前程',
          text: '后座舱配备科技感十足的触屏式遥控装置（Touch Screen Remote）\n诸多功能尽在掌控，从容优雅一路随行',
        },
      ],
    },
    {
      songId: 102385094,
      data: [
        {
          title: '游刃有余，尽在掌握',
          text: '可分屏式12.3英寸中央触摸屏\n驾乘信息一览无余，从容操控',
        },
        {
          title: '随心所驭，肆意驰骋',
          text: '三种驾驶模式任意切换\n为您提供澎湃卓然，静谧流畅的驾乘体验',
        },
        {
          title: '畅意互联，智享无限',
          text: '先进的My Bentley车联网服务功能\n让您无论身在何处，皆可运筹帷幄',
        },
      ],
    },
    {
      songId: 310637306,
      data: [
        {
          title: '臻美阔境，雅韵天成',
          text: 'Mulline车型专属三色内饰配色彰显尊雅品味\n宽绰四座配置缔造从容阔境',
        },
        {
          title: '细节之悦，尊雅呈现',
          text: '惊艳的Mulliner 3D木饰车门嵌板\n感触独特技艺，缔造怡人之境',
        },
        {
          title: '触目所及，皆是吸引',
          text: '数字式仪表显示屏让驾驶信息一览无余\n高质感双色方向盘，让奢适触手即享',
        },
      ],
    },
  ]

  let audioDemo
  function showDetailPage() {
    $('.page_detail').removeClass('detail_1', 'detail_2', 'detail_3', 'detail_4')
    $('.page_detail').addClass(`detail_${Number(selectSceneIndex) + 1}`)
    showSection('.page_detail')
    const { data, songId } = detailData[selectSceneIndex]
    for (let i = 0; i < data.length; i++) {
      const item = data[i]
      $(`.detail_item${i + 1} .detail_operation__hint`).text(item.title)
      $(`.detail_item${i + 1} .detail_operation__btn`).text(item.text)
    }
    var previewBody = new Swiper('.detail_swiper', {
      autoplay: 3000,
      autoplayDisableOnInteraction: false,
      loop: true,
      noSwiping: true,
    })
    audioId = songId
    audioDemo = new PlayKernelSong({
      songId: audioId,
      loop: true,
    })
    audioDemo.play()
  }

  $('.page_icon__skip').on('click', function () {
    // audioDemo && audioDemo.stop()
    showSection('.page_station')
    $('.page_detail').removeClass('station_1', 'station_2', 'station_3', 'station_4')
    $('.page_station').addClass(`station_${Number(selectSceneIndex) + 1}`)
  })

  $('.station_operation__btn1').on('click', function () {
    audioDemo && audioDemo.stop()
    audioId = ''
    $('.body_inner').scrollLeft(0)
    showSection('.page_select')
    lockNext = false
    selectSceneIndex = 0
  })

  $('.station_operation__btn2').on('click', function () {
    audioDemo && audioDemo.stop()
    audioId = ''
    showSection('.page_form')
  })

  function formVerify() {
    var regex =
      /^(13[0-9]{9})|(15[0-9]{9})|(17[0-9]{9})|(18[0-9]{9})|(19[0-9]{9})$/

    if (
      $('#formName').val() === '' ||
      $('#formAppellation').val() === '' ||
      $('#formPhone').val() === '' ||
      $('#formDealer').val() === ''
    ) {
      $('.modal_hint__text').text('请完整填写信息')
      $('#modalHint').addClass('show')
      return false
    } else if (!regex.test($('#formPhone').val())) {
      $('#modalHint').addClass('show')
      $('.modal_hint__text').text('请正确填写手机号')
    } else {
      return true
    }
  }
  $('.modal_hint__btn').on('click', function () {
    $('#modalHint').removeClass('show')
  })
  $('.form_btn__subscribe').on('click', function () {
    $('#shareImg').attr(
      'src',
      `./img/share_img${Number(selectSceneIndex) + 1}.jpg`
    )
    formVerify() && showSection('.page_share')
  })
  $('.form_btn__share').on('click', function () {
    $('#shareImg').attr(
      'src',
      `./img/share_img${Number(selectSceneIndex) + 1}.jpg`
    )
    showSection('.page_share')
  })
  $('.page_icon__return').on('click', function () {
    $('.body_inner').scrollLeft(0)
    showSection('.page_select')
    lockNext = false
    audioUrl = ''
    new OriginalAudio({ url: audioUrl })
  })

  $('.page_icon__voice').on('click', function () {
    // 判断是否存在可播放的音频
    if (audioUrl === '' && audioId === '') {
      return
    }
    palyVoice = !palyVoice
    if (palyVoice) {
      $('.page_icon__voice').removeClass('stop')
      if (audioUrl !== '') {
        console.log(audioUrl)
        let audio1 = new OriginalAudio({ url: audioUrl, loop: true })
        audio1.play()
      } else if (audioId !== '') {
        audioDemo.play()
      }
    } else {
      $('.page_icon__voice').addClass('stop')
      if (audioUrl !== '') {
        new OriginalAudio({ url: '' })
        console.log('暂停', audioUrl)
      } else if (audioId !== '') {
        audioDemo.stop()
      }
    }
  })
  // document.body.addEventListener(
  //   'touchmove',
  //   function (e) {
  //     e.preventDefault() //阻止默认的处理方式(阻止下拉滑动的效果)
  //   },
  //   { passive: false }
  // ) //passive 参数不能省略，用来兼容ios和android
  // $('.body_inner')[0].removeEventListener(
  //   'touchmove',
  //   function (e) {
  //     e.preventDefault()//阻止默认的处理方式(阻止下拉滑动的效果)
  //   },
  //   { passive: false }
  // ) //passive 参数不能省略，用来兼容ios和androidW
})
